# Changelog
All notable changes to this project will be documented in this file.

## [1.0] - 30-09-2019
- First published version for Manning's MEAP program
- Contains supporting Docker image and code for chapter 1, 2 and 3.
